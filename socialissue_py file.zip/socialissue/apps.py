from django.apps import AppConfig


class SocialissueConfig(AppConfig):
    name = 'socialissue'
